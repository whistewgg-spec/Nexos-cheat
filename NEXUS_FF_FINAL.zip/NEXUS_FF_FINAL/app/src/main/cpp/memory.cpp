#include "memory.h"
#include "esp.h"
#include <sys/uio.h>
#include <sys/types.h>
#include <dirent.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstring>
#include <cstdio>
#include <android/log.h>

#define LOG_TAG "NexusCore"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace Memory {

pid_t     target_pid  = -1;
uintptr_t il2cpp_base = 0;

static pid_t FindPidByName(const std::string& name) {
    DIR* dir = opendir("/proc");
    if (!dir) return -1;
    struct dirent* entry;
    char buf[512];
    while ((entry = readdir(dir)) != nullptr) {
        if (entry->d_type != DT_DIR) continue;
        pid_t pid = (pid_t)atoi(entry->d_name);
        if (pid <= 0) continue;
        snprintf(buf, sizeof(buf), "/proc/%d/cmdline", pid);
        int fd = open(buf, O_RDONLY);
        if (fd < 0) continue;
        ssize_t n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n <= 0) continue;
        buf[n] = '\0';
        if (strstr(buf, name.c_str())) {
            closedir(dir);
            LOGI("PID: %d %s", pid, name.c_str());
            return pid;
        }
    }
    closedir(dir);
    return -1;
}

uintptr_t GetModuleBase(pid_t pid, const std::string& lib_name) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE* f = fopen(path, "r");
    if (!f) return 0;
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, lib_name.c_str()) && strstr(line, "r-xp")) {
            uintptr_t base = (uintptr_t)strtoull(line, nullptr, 16);
            fclose(f);
            LOGI("Base %s: 0x%llX", lib_name.c_str(), (unsigned long long)base);
            return base;
        }
    }
    fclose(f);
    return 0;
}

bool Init(const std::string& nome) {
    target_pid = FindPidByName(nome);
    if (target_pid <= 0) return false;
    il2cpp_base = GetModuleBase(target_pid, "libil2cpp.so");
    return il2cpp_base != 0;
}

bool ReadBuffer(uintptr_t addr, void* buf, size_t size) {
    struct iovec local  = { buf,         size };
    struct iovec remote = { (void*)addr, size };
    ssize_t n = process_vm_readv(target_pid, &local, 1, &remote, 1, 0);
    if (n == (ssize_t)size) return true;
    char p[64];
    snprintf(p, sizeof(p), "/proc/%d/mem", target_pid);
    int fd = open(p, O_RDONLY);
    if (fd < 0) return false;
    n = pread(fd, buf, size, (off_t)addr);
    close(fd);
    return n == (ssize_t)size;
}

bool WriteBuffer(uintptr_t addr, const void* buf, size_t size) {
    struct iovec local  = { (void*)buf,  size };
    struct iovec remote = { (void*)addr, size };
    ssize_t n = process_vm_writev(target_pid, &local, 1, &remote, 1, 0);
    if (n == (ssize_t)size) return true;
    char p[64];
    snprintf(p, sizeof(p), "/proc/%d/mem", target_pid);
    int fd = open(p, O_RDWR);
    if (fd < 0) return false;
    n = pwrite(fd, buf, size, (off_t)addr);
    close(fd);
    return n == (ssize_t)size;
}

template<typename T>
T Read(uintptr_t addr) {
    T val{};
    ReadBuffer(addr, &val, sizeof(T));
    return val;
}

template<typename T>
bool Write(uintptr_t addr, T value) {
    return WriteBuffer(addr, &value, sizeof(T));
}

uintptr_t WalkChain(uintptr_t base, const uintptr_t* offsets, size_t count) {
    uintptr_t addr = base;
    for (size_t i = 0; i < count - 1; i++) {
        uintptr_t next = 0;
        ReadBuffer(addr + offsets[i], &next, sizeof(next));
        addr = next;
        if (!addr) return 0;
    }
    return addr + offsets[count - 1];
}

bool IsValid() { return target_pid > 0 && il2cpp_base != 0; }

template float     Read<float>(uintptr_t);
template int       Read<int>(uintptr_t);
template uint32_t  Read<uint32_t>(uintptr_t);
template uintptr_t Read<uintptr_t>(uintptr_t);
template Vector3   Read<Vector3>(uintptr_t);
template bool      Write<float>(uintptr_t, float);
template bool      Write<int>(uintptr_t, int);
template bool      Write<uint32_t>(uintptr_t, uint32_t);

}
