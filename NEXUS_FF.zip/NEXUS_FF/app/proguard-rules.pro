-keep class com.nexus.ff.NexusCore { *; }
-keepclassmembers class com.nexus.ff.NexusCore {
    native <methods>;
}
-keep class com.nexus.ff.data.** { *; }
-dontwarn kotlin.**
-optimizationpasses 5
-dontusemixedcaseclassnames
-repackageclasses ''
