package com.nexus.ff.ui.modules

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import com.nexus.ff.NexusCore
import com.nexus.ff.R

class EspFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, c: ViewGroup?, s: Bundle?) =
        inflater.inflate(R.layout.fragment_esp, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        val switchMain  = v.findViewById<Switch>(R.id.switchEspMain)
        val switchBox   = v.findViewById<Switch>(R.id.switchEspBox)
        val switchSkel  = v.findViewById<Switch>(R.id.switchEspSkeleton)
        val switchHp    = v.findViewById<Switch>(R.id.switchEspHealth)
        val switchDist  = v.findViewById<Switch>(R.id.switchEspDistance)
        val sliderDist  = v.findViewById<SeekBar>(R.id.sliderEspDistance)
        val tvDist      = v.findViewById<TextView>(R.id.tvEspDistance)

        sliderDist.max = 500
        sliderDist.progress = 300
        tvDist.text = "300m"

        fun applyConfig() {
            NexusCore.setEspEnabled(switchMain.isChecked)
            NexusCore.setEspConfig(
                switchBox.isChecked, switchSkel.isChecked,
                switchHp.isChecked, switchDist.isChecked,
                sliderDist.progress.toFloat(),
                0xFFFF3333.toInt(), 0xFF33FF33.toInt()
            )
        }

        switchMain.setOnCheckedChangeListener  { _, _ -> applyConfig() }
        switchBox.setOnCheckedChangeListener   { _, _ -> applyConfig() }
        switchSkel.setOnCheckedChangeListener  { _, _ -> applyConfig() }
        switchHp.setOnCheckedChangeListener    { _, _ -> applyConfig() }
        switchDist.setOnCheckedChangeListener  { _, _ -> applyConfig() }
        sliderDist.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) {
                tvDist.text = "${p}m"; applyConfig()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }
}
