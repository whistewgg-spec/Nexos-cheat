package com.nexus.ff.ui.modules

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import com.nexus.ff.NexusCore
import com.nexus.ff.R

class HitboxFragment : Fragment() {
    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?) =
        i.inflate(R.layout.fragment_generic_module, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        val switchMain = v.findViewById<Switch>(R.id.switchModuleMain)
        val sliderA    = v.findViewById<SeekBar>(R.id.sliderModuleA)
        val sliderB    = v.findViewById<SeekBar>(R.id.sliderModuleB)
        val tvA        = v.findViewById<TextView>(R.id.tvSliderAValue)
        val tvB        = v.findViewById<TextView>(R.id.tvSliderBValue)
        val tvTitle    = v.findViewById<TextView>(R.id.tvModuleTitle)

        tvTitle.text   = "HITBOX"
        sliderA.max    = 100; sliderB.max = 100
        sliderA.progress = 50; sliderB.progress = 50
        tvA.text = "50"; tvB.text = "50"

        switchMain.setOnCheckedChangeListener { _, enabled ->
            when ("HitboxFragment") {
                "AimlockFragment"     -> NexusCore.setAimlockEnabled(enabled)
                "NoRecoilFragment"    -> NexusCore.setAimbotConfig(90f,5f,7,false,0.75f,false,enabled,false)
                "MagicBulletFragment" -> NexusCore.setAimbotConfig(90f,5f,7,enabled,0.75f,false,false,false)
                "TrackingFragment"    -> NexusCore.setAimbotConfig(90f,5f,7,false,0.75f,false,false,enabled)
                else -> {}
            }
        }
        val listener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) {
                when (sb?.id) {
                    R.id.sliderModuleA -> tvA.text = ""
                    R.id.sliderModuleB -> tvB.text = ""
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        }
        sliderA.setOnSeekBarChangeListener(listener)
        sliderB.setOnSeekBarChangeListener(listener)
    }
}
