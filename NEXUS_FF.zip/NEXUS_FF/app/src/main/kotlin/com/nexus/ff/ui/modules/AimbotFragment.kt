package com.nexus.ff.ui.modules

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import com.nexus.ff.NexusCore
import com.nexus.ff.R

class AimbotFragment : Fragment() {
    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?) =
        i.inflate(R.layout.fragment_aimbot, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        val switchMain    = v.findViewById<Switch>(R.id.switchAimbotMain)
        val sliderFov     = v.findViewById<SeekBar>(R.id.sliderFov)
        val sliderSmooth  = v.findViewById<SeekBar>(R.id.sliderSmooth)
        val spinnerBone   = v.findViewById<Spinner>(R.id.spinnerBone)
        val tvFov         = v.findViewById<TextView>(R.id.tvFovValue)
        val tvSmooth      = v.findViewById<TextView>(R.id.tvSmoothValue)

        sliderFov.max = 180; sliderFov.progress = 90
        sliderSmooth.max = 20; sliderSmooth.progress = 5
        tvFov.text = "90°"; tvSmooth.text = "5"

        val bones = arrayOf("Cabeça", "Pescoço", "Peito")
        spinnerBone.adapter = ArrayAdapter(requireContext(),
            android.R.layout.simple_spinner_item, bones)

        fun apply() {
            NexusCore.setAimbotEnabled(switchMain.isChecked)
            val boneIdx = when(spinnerBone.selectedItemPosition) {
                0 -> 7; 1 -> 6; else -> 5
            }
            NexusCore.setAimbotConfig(
                sliderFov.progress.toFloat(),
                sliderSmooth.progress.toFloat().coerceAtLeast(1f),
                boneIdx, false, 0.75f, false, false, false
            )
        }

        switchMain.setOnCheckedChangeListener { _, _ -> apply() }
        sliderFov.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) {
                tvFov.text = "${p}°"; apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        sliderSmooth.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) {
                tvSmooth.text = "$p"; apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        spinnerBone.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v2: View?, p: Int, i: Long) = apply()
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
    }
}
