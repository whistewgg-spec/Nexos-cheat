package com.nexus.ff.ui

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.nexus.ff.ui.modules.*

class ModulePagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {

    private val pages = listOf(
        "ESP"         to { EspFragment() as Fragment },
        "AIMBOT"      to { AimbotFragment() as Fragment },
        "AIMLOCK"     to { AimlockFragment() as Fragment },
        "NO RECOIL"   to { NoRecoilFragment() as Fragment },
        "MAGIC"       to { MagicBulletFragment() as Fragment },
        "HEAD 75%"    to { HeadshotFragment.newInstance(0.75f) as Fragment },
        "HEAD 100%"   to { HeadshotFragment.newInstance(1.0f) as Fragment },
        "AIM FOV"     to { AimFovFragment() as Fragment },
        "BOT FOV"     to { AimbotFovFragment() as Fragment },
        "CROSSHAIR"   to { CrosshairFragment() as Fragment },
        "TRACKING"    to { TrackingFragment() as Fragment },
        "HITBOX"      to { HitboxFragment() as Fragment }
    )

    override fun getItemCount() = pages.size
    override fun createFragment(pos: Int) = pages[pos].second()
    fun getPageTitle(pos: Int) = pages[pos].first
}
