package com.nexus.ff

import android.util.Log

object NexusCore {

    private const val TAG = "NexusCore"

    init {
        try {
            System.loadLibrary("nexus_core")
            Log.i(TAG, "nexus_core.so carregada")
        } catch (e: UnsatisfiedLinkError) {
            Log.e(TAG, "Falha ao carregar nexus_core.so: ${e.message}")
        }
    }

    // --- Controle geral ---
    external fun nativeInit(): Boolean
    external fun nativeStop()
    external fun nativeIsAttached(): Boolean
    external fun setScreenSize(w: Int, h: Int)

    // --- ESP ---
    external fun setEspEnabled(enabled: Boolean)
    external fun setEspConfig(
        box: Boolean, skeleton: Boolean, health: Boolean,
        distance: Boolean, maxDist: Float,
        colorEnemy: Int, colorTeam: Int
    )

    // --- Aimbot ---
    external fun setAimbotEnabled(enabled: Boolean)
    external fun setAimlockEnabled(enabled: Boolean)
    external fun setAimbotConfig(
        fov: Float, smoothness: Float, targetBone: Int,
        magicBullet: Boolean, headshotChance: Float,
        headshot100: Boolean, noRecoil: Boolean, tracking: Boolean
    )

    // --- Dados de entidades para overlay ---
    external fun getEntitiesJson(): String

    // Wrapper de conveniência
    fun start(screenW: Int, screenH: Int): Boolean {
        setScreenSize(screenW, screenH)
        return nativeInit()
    }
}
