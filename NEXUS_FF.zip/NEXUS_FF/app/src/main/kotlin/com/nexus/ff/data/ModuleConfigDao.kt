package com.nexus.ff.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ModuleConfigDao {
    @Query("SELECT * FROM module_configs WHERE profileId = :profileId")
    fun getConfigsForProfile(profileId: Int): Flow<List<ModuleConfigEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertConfig(config: ModuleConfigEntity)

    @Query("SELECT * FROM module_configs WHERE moduleId = :moduleId AND profileId = :profileId")
    suspend fun getConfig(moduleId: String, profileId: Int): ModuleConfigEntity?
}
