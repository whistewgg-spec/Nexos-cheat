// aimbot.cpp
#include "aimbot.h"
#include "memory.h"
#include "offsets.h"
#include <cmath>
#include <android/log.h>
#include <limits>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "NexusAim", __VA_ARGS__)
#define PI 3.14159265358979f
#define DEG2RAD(x) ((x) * PI / 180.0f)
#define RAD2DEG(x) ((x) * 180.0f / PI)

namespace Aimbot {

    Config cfg;

    static float Distance2D(float ax, float ay, float bx, float by) {
        float dx = ax - bx, dy = ay - by;
        return sqrtf(dx*dx + dy*dy);
    }

    EntityInfo* FindBestTarget(float scx, float scy, int sw, int sh) {
        auto& ents = ESP::GetEntities();
        float fov_px = tanf(DEG2RAD(cfg.fov * 0.5f)) * (float)sw;

        EntityInfo* best = nullptr;
        float best_dist = fov_px;

        for (auto& e : ents) {
            if (!e.is_alive) continue;
            Vector2 screen = ESP::BoneToScreen(e.bones[cfg.target_bone], sw, sh);
            if (screen.x < 0 || screen.y < 0) continue;
            float d = Distance2D(scx, scy, screen.x, screen.y);
            if (d < best_dist) {
                best_dist = d;
                // cast away const — controlado
                best = const_cast<EntityInfo*>(&e);
            }
        }
        return best;
    }

    void AimAt(const EntityInfo& target, float scx, float scy, int sw, int sh) {
        // Escolhe osso alvo: se headshot_100 sempre cabeça, senão cfg.target_bone
        int bone = cfg.headshot_100 ? offsets::BONE_HEAD : cfg.target_bone;
        // Probabilidade de headshot 75%
        if (!cfg.headshot_100 && cfg.headshot_chance > 0.0f) {
            static int counter = 0;
            bone = ((counter++ % 4) < (int)(cfg.headshot_chance * 4.0f))
                   ? offsets::BONE_HEAD : offsets::BONE_CHEST;
        }

        Vector2 screen = ESP::BoneToScreen(target.bones[bone], sw, sh);
        if (screen.x < 0) return;

        float dx = screen.x - scx;
        float dy = screen.y - scy;

        // Suavização: move fração do delta
        float step = 1.0f / cfg.smoothness;
        float move_x = dx * step;
        float move_y = dy * step;

        // Lê ângulos atuais da câmera
        float yaw   = Memory::Read<float>(Memory::il2cpp_base + offsets::CameraYaw);
        float pitch = Memory::Read<float>(Memory::il2cpp_base + offsets::CameraPitch);

        // Converte pixels para graus (aproximação linear por FOV)
        float fov_rad = DEG2RAD(Memory::Read<float>(Memory::il2cpp_base + offsets::CameraFOV));
        float px_per_deg = (float)sw / RAD2DEG(fov_rad);

        yaw   += move_x / px_per_deg;
        pitch -= move_y / px_per_deg;  // invertido: Y+ = baixo em tela

        SetCameraAngle(yaw, pitch);
    }

    void SetCameraAngle(float yaw, float pitch) {
        Memory::Write<float>(Memory::il2cpp_base + offsets::CameraYaw,   yaw);
        Memory::Write<float>(Memory::il2cpp_base + offsets::CameraPitch, pitch);
    }

    void SuppressRecoil(uintptr_t weapon_addr) {
        if (!cfg.no_recoil || !weapon_addr) return;
        Memory::Write<float>(weapon_addr + offsets::WeaponRecoilX, 0.0f);
        Memory::Write<float>(weapon_addr + offsets::WeaponRecoilY, 0.0f);
    }

    void ApplyMagicBullet(uintptr_t weapon_addr) {
        if (!cfg.magic_bullet || !weapon_addr) return;
        // Força spread = 0 e velocidade máxima de bala
        Memory::Write<float>(weapon_addr + offsets::WeaponSpread, 0.0f);
        Memory::Write<float>(weapon_addr + offsets::BulletVelocity, 99999.0f);
    }

    void SetEnabled(bool v) { cfg.enabled = v; }
    void SetAimlock(bool v) { cfg.aimlock = v; }
}
