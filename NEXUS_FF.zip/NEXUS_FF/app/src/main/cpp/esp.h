#pragma once
#include <cstdint>
#include <vector>
#include <array>

struct Vector3 { float x, y, z; };
struct Vector2 { float x, y; };

struct Matrix4x4 {
    float m[4][4];
    // Projeta Vector3 de mundo para tela
    Vector2 WorldToScreen(const Vector3& world, int screen_w, int screen_h) const;
};

struct EntityInfo {
    uintptr_t base_addr;
    Vector3   position;
    float     health;
    float     health_max;
    int       team_id;
    bool      is_alive;
    std::array<Vector3, 10> bones;  // posições dos ossos no mundo
};

namespace ESP {
    struct Config {
        bool enabled         = false;
        bool show_box        = true;
        bool show_skeleton   = true;
        bool show_health     = true;
        bool show_distance   = true;
        bool show_name       = false;
        float max_distance   = 300.0f;
        // Cores ARGB
        uint32_t color_enemy   = 0xFFFF3333;
        uint32_t color_team    = 0xFF33FF33;
        uint32_t color_skeleton= 0xFFFFFFFF;
    };

    extern Config cfg;

    // Atualiza lista de entidades do jogo
    void Update();

    // Retorna snapshot atual das entidades visíveis
    const std::vector<EntityInfo>& GetEntities();

    // Converte posição de osso para coordenada de tela
    Vector2 BoneToScreen(const Vector3& bone_world, int sw, int sh);

    void SetEnabled(bool v);
}
